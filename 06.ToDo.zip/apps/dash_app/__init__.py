# dash_app/__init__.py

from .app1 import dash_app

__all__ = ['dash_app']
